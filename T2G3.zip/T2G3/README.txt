Unidade Curricular: Sistemas Operativos

Durante a implementação do nosso trabalho, confrontamo-nos com algumas dificuldades em relação:
- À criação do ficheiro de registos: a abertura e o fecho do ficheiro é feita cada vez que é preciso ser escrita uma linha de texto. Optamos por fazer desta forma, uma vez que não era possível escrever tudo quando a abertura e o fecho era feita no inicio e no final do programa.
- À ocorrencia do erro EPERM: foi verificado o pid do grupo que é igual ao dos outros, no entanto o erro é ocorrido e permanece um mistério para nós.
- À comunicação entre pipes: esta é feita a partir do stderror.
- Aos valores diferentes que aparecem quando é ocorrido o erro e que só correndo o programa uma outra vez, o resultado é o correto.


Turma 7 Grupo 3:
- Diogo Filipe de Oliveira Santos;
- Jéssica Mireie Fernandes do Nascimento;
- Marcelo Augusto Reis;

